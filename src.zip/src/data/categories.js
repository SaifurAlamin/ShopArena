export const categories = [
  { id: 1, name: "Electronics", icon: "💻", image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=500" },
  { id: 2, name: "Fashion", icon: "👕", image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=500" },
  { id: 3, name: "Home & Living", icon: "🏠", image: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=500" },
  { id: 4, name: "Beauty", icon: "✨", image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500" },
  { id: 5, name: "Sports", icon: "⚽", image: "https://images.unsplash.com/photo-146uy6329263-4d5f1e4c9a3a?w=500" },
  { id: 6, name: "Books", icon: "📚", image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=500" },
];