import { Link } from "react-router-dom";
import { FiArrowRight, FiHeart, FiShoppingBag, FiStar } from "react-icons/fi";
import { toast } from "react-toastify";
import { categories } from "../../data/categories";
import { products } from "../../data/products";
import { useCart } from "../../hooks/useCart";
import { useDispatch, useSelector } from "react-redux";
import { toggleWishlist } from "../../features/wishlist/wishlistSlice";
import { formatCurrency } from "../../utils/formatters";
import { getDiscountPercentage } from "../../utils/helpers";

function ProductCard({ product }) {
  const { add } = useCart();
  const dispatch = useDispatch();
  const wishlist = useSelector((state) => state.wishlist.items);
  const isWishlisted = wishlist.some((item) => item.id === product.id);

  const handleAdd = () => {
    add(product);
    toast.success("Product added to cart");
  };

  return (
    <div className="product-card h-100">
      <div className="product-image-wrap">
        <Link to={`/products/${product.id}`}>
          <img src={product.image} alt={product.name} className="product-image" />
        </Link>
        {product.oldPrice > product.price && <span className="discount-tag">{getDiscountPercentage(product.price, product.oldPrice)}% OFF</span>}
        <button className={`wishlist-btn ${isWishlisted ? "active" : ""}`} onClick={() => dispatch(toggleWishlist(product))} aria-label="Toggle wishlist">
          <FiHeart />
        </button>
      </div>
      <div className="p-3">
        <div className="small text-muted">{product.category}</div>
        <Link to={`/products/${product.id}`} className="product-name">{product.name}</Link>
        <div className="d-flex align-items-center gap-1 small text-warning my-2"><FiStar fill="currentColor" /> <span className="text-muted">{product.rating}</span></div>
        <div className="d-flex align-items-center gap-2 mb-3">
          <strong className="text-primary">{formatCurrency(product.price)}</strong>
          {product.oldPrice > product.price && <del className="small text-muted">{formatCurrency(product.oldPrice)}</del>}
        </div>
        <button className="btn btn-outline-primary btn-sm w-100" onClick={handleAdd}><FiShoppingBag className="me-2" />Add to Cart</button>
      </div>
    </div>
  );
}

export default function Home() {
  const featured = products.filter((product) => product.featured);
  return (
    <>
      <section className="hero-section">
        <div className="container">
          <div className="row align-items-center min-vh-50">
            <div className="col-lg-6 py-5">
              <span className="hero-kicker">THE EVERYDAY SHOPPING STORE</span>
              <h1 className="display-4 fw-bold mt-3">Find your next <span>favorite</span> thing.</h1>
              <p className="text-secondary fs-5 mt-3">Discover quality products, great prices, and a smoother shopping experience.</p>
              <Link to="/products" className="btn btn-primary btn-lg mt-3">Explore Products <FiArrowRight className="ms-2" /></Link>
            </div>
            <div className="col-lg-6 d-none d-lg-block text-center">
              <img className="hero-image" src="https://images.unsplash.com/photo-1607082349566-187342175e2f?w=900" alt="Shopping collection" />
            </div>
          </div>
        </div>
      </section>

      <section className="container py-5">
        <div className="section-heading">
          <div><span className="section-kicker">BROWSE COLLECTIONS</span><h2>Shop by Category</h2></div>
          <Link to="/categories">View all <FiArrowRight /></Link>
        </div>
        <div className="row g-3">
          {categories.map((category) => (
            <div className="col-6 col-md-4 col-lg-2" key={category.id}>
              <Link to={`/products?category=${encodeURIComponent(category.name)}`} className="category-card">
                <img src={category.image} alt={category.name} />
                <span>{category.name}</span>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="container pb-5">
        <div className="section-heading">
          <div><span className="section-kicker">HANDPICKED FOR YOU</span><h2>Featured Products</h2></div>
          <Link to="/products">Shop all <FiArrowRight /></Link>
        </div>
        <div className="row g-4">
          {featured.map((product) => <div className="col-6 col-md-4 col-lg-3" key={product.id}><ProductCard product={product} /></div>)}
        </div>
      </section>

      <section className="container pb-5">
        <div className="promo-banner">
          <div><span>LIMITED TIME OFFER</span><h2>Make room for something new.</h2><p className="mb-3">Explore selected deals across the store.</p><Link to="/products" className="btn btn-light">Shop deals</Link></div>
        </div>
      </section>
    </>
  );
}